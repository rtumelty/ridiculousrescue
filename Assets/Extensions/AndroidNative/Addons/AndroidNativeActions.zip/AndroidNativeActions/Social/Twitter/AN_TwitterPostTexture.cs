using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Android Native - Social")]
	public class AN_TwitterPostTexture : FsmStateAction {
		
		public FsmString message;
		public FsmTexture texture;
		
		public FsmEvent successEvent;
		public FsmEvent failEvent;
		
		
		public override void OnEnter() {
			
			bool IsInEdditorMode = false;
			
			#if UNITY_EDITOR
			IsInEdditorMode = true;
			#endif
			
			
			if(IsInEdditorMode) {
				Fsm.Event(successEvent);
				Finish();
				return;
			}
			
			
			AndroidTwitterManager.instance.addEventListener(TwitterEvents.POST_SUCCEEDED,  OnPostSuccses);
			AndroidTwitterManager.instance.addEventListener(TwitterEvents.POST_FAILED,  	  OnPostFailed);
			
			AndroidTwitterManager.instance.Post(message.Value, texture.Value as Texture2D);
			
		}

		private void RemoveListeners() {
			AndroidTwitterManager.instance.removeEventListener(TwitterEvents.POST_SUCCEEDED,  OnPostSuccses);
			AndroidTwitterManager.instance.removeEventListener(TwitterEvents.POST_FAILED,  	  OnPostFailed);
		}
		
		
		private void OnPostFailed() {
			Fsm.Event(failEvent);
			RemoveListeners();
			Finish();
		}
		
		private void OnPostSuccses() {
			Fsm.Event(successEvent);
			RemoveListeners();
			Finish();
		}
		
	}
}



